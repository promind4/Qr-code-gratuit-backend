from enum import Enum
from typing import Optional

from pydantic import BaseModel, Field, HttpUrl, validator


class QRCodeFormat(str, Enum):
    png = "png"
    jpeg = "jpeg"
    svg = "svg"
    pdf = "pdf"


class QRCodeRequest(BaseModel):
    content: str = Field(..., min_length=1, max_length=1000)
    format: QRCodeFormat = QRCodeFormat.png
    size: int = Field(300, ge=100, le=1000)
    color: str = Field("#000000", regex=r"^#([A-Fa-f0-9]{6})$")
    background: str = Field("#FFFFFF", regex=r"^#([A-Fa-f0-9]{6})$")
    margin: int = Field(4, ge=0, le=50)
    error_correction: str = Field("M")

    @validator("error_correction")
    def check_error_correction(cls, value: str) -> str:
        allowed = {"L", "M", "Q", "H"}
        if value not in allowed:
            raise ValueError("Erreur inconnue (L, M, Q, H attendus)")
        return value


class QRCodeResponse(BaseModel):
    request_id: str
    format: QRCodeFormat
    size: int
    error_correction: str
