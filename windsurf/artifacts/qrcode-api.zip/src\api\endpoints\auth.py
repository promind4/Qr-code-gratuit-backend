from datetime import timedelta

from fastapi import APIRouter, Depends, HTTPException, status

from src.core.config import settings
from src.core.security import authenticate_user, create_access_token
from src.schemas.token import TokenRequest, TokenResponse

router = APIRouter(prefix="/api/v1/auth", tags=["auth"])


@router.post("/token", response_model=TokenResponse)
def login_for_access_token(payload: TokenRequest) -> TokenResponse:
    user = authenticate_user(payload.username, payload.password)
    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Identifiants invalides",
            headers={"WWW-Authenticate": "Bearer"},
        )
    access_token = create_access_token(
        data={"sub": user["username"]},
        expires_delta=timedelta(minutes=settings.token_expire_minutes),
    )
    return TokenResponse(
        access_token=access_token,
        expires_in=settings.token_expire_minutes * 60,
    )
