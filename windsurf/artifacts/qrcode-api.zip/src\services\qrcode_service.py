from io import BytesIO
from uuid import uuid4

from PIL import Image
import qrcode
from qrcode.constants import (
    ERROR_CORRECT_L,
    ERROR_CORRECT_M,
    ERROR_CORRECT_Q,
    ERROR_CORRECT_H,
)
from qrcode.image.pil import PilImage
from qrcode.image.svg import SvgImage

from src.schemas.qrcode import QRCodeFormat, QRCodeRequest

ERROR_CORRECTION_MAP = {
    "L": ERROR_CORRECT_L,
    "M": ERROR_CORRECT_M,
    "Q": ERROR_CORRECT_Q,
    "H": ERROR_CORRECT_H,
}

CONTENT_TYPES = {
    QRCodeFormat.png: "image/png",
    QRCodeFormat.jpeg: "image/jpeg",
    QRCodeFormat.svg: "image/svg+xml",
    QRCodeFormat.pdf: "application/pdf",
}


def _build_qr(payload: QRCodeRequest) -> qrcode.QRCode:
    return qrcode.QRCode(
        version=None,
        error_correction=ERROR_CORRECTION_MAP[payload.error_correction],
        box_size=10,
        border=payload.margin,
    )


def _render_pil(payload: QRCodeRequest) -> Image.Image:
    qr = _build_qr(payload)
    qr.add_data(payload.content)
    qr.make(fit=True)
    pil_img = qr.make_image(
        image_factory=PilImage,
        fill_color=payload.color,
        back_color=payload.background,
    ).get_image()
    return pil_img.resize((payload.size, payload.size), Image.LANCZOS)


def generate_qr(payload: QRCodeRequest) -> tuple[str, bytes, str]:
    request_id = str(uuid4())
    if payload.format == QRCodeFormat.svg:
        qr = _build_qr(payload)
        qr.add_data(payload.content)
        qr.make(fit=True)
        svg = qr.make_image(
            image_factory=SvgImage,
            fill_color=payload.color,
            back_color=payload.background,
        )
        return request_id, svg.to_string().encode("utf-8"), CONTENT_TYPES[payload.format]

    pil_image = _render_pil(payload)
    buffer = BytesIO()
    output_format = payload.format.value.upper()
    if payload.format == QRCodeFormat.pdf:
        pil_image.convert("RGB").save(buffer, format="PDF")
    else:
        pil_image.convert("RGB").save(buffer, format=output_format, quality=95)
    return request_id, buffer.getvalue(), CONTENT_TYPES[payload.format]
