from fastapi import Depends, FastAPI, Request
from fastapi.responses import JSONResponse
from slowapi.errors import RateLimitExceeded
from slowapi.middleware import SlowAPIMiddleware

from src.api.endpoints.auth import router as auth_router
from src.api.endpoints.qrcode import router as qrcode_router
from src.core.config import settings
from src.core.rate_limiter import limiter


app = FastAPI(
    title="QR Code Generation API",
    version="1.0.0",
    description="Stateless API générant des QR codes de différentes formes et formats.",
)

app.state.limiter = limiter
app.add_middleware(SlowAPIMiddleware, limiter=limiter)

app.include_router(auth_router)
app.include_router(qrcode_router)


@app.get("/health", tags=["health"])
def health_check() -> JSONResponse:
    return JSONResponse(
        status_code=200,
        content={"status": "ok", "environment": settings.environment},
    )


@app.exception_handler(RateLimitExceeded)
async def rate_limit_handler(request: Request, exc: RateLimitExceeded) -> JSONResponse:
    return JSONResponse(
        status_code=429,
        content={
            "detail": "Trop de requêtes envoyées ; veuillez réessayer plus tard.",
            "error_code": "RATE001",
        },
    )
